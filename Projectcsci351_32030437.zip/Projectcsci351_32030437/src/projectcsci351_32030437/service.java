package projectcsci351_32030437;

import java.util.Date;

public class service {

    private String name; // global
    private int number; // global
    private double balance; // global
    private Date date; // global

    public service() {

        name = "Customer";
        date = new Date();

    }

    public service(String name, int number, double balance) {
        this.name = name;
        this.number = number;
        this.balance = balance;
        date = new Date();
    }

    public int getNumber() {
        return number;
    }

    public String getName() {
        return name;
    }

    public double getBalance() {
        return balance;
    }

    public double get1GBsevice() {
        return balance - 2;
    }

    public double get2GBservice() {
        return balance - 5;
    }

    public double get5GBservice() {
        return balance - 12;
    }

    public double get10GBservice() {
        return balance - 20;
    }

    public double get5GBand300MBwpservice() {
        return balance - 24;
    }

    public double addToBalance() {
        return balance += getBalance();
    }

    public String toString1() {
        return "\nDear " + name + "\nyour phone number is " + number + " and your balance is " + getBalance() + " " + date.toString();
    }

    public String toString2() {
        return "\nDear " + name + "\nthe availabe services are:\n1GB sevice\n2GB service\n5GB service\n10GB service\n5GB and 300MB whatsappp service.";
    }

    public String toString3() {
        return "\nThank you for choosing us " + getName() + " :/";
    }

}
