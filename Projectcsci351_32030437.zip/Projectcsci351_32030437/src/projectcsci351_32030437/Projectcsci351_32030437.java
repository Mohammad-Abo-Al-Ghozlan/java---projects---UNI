/** **************************************************
 * Mohammad Abo Al Ghozlan - 32030437 - CSCI351 project
 *************************************************** */
package projectcsci351_32030437;

import java.util.*;

public class Projectcsci351_32030437 {

    public static void main(String[] args) {
        Scanner s = new Scanner(System.in);
        System.out.print("Enter the name, the phone number, and the balance: ");
        service costumer1; // global
        customer1 = new service(s.next(), s.nextInt(), s.nextDouble()); // variables of custumer1 are local

        while (true) {
            System.out.println("\n-----------------------------------");
            System.out.println("To display all info press 1");
            System.out.println("To display all the services press 2");
            System.out.println("To subscribe to a service press 3");
            System.out.println("To go to costumer care press 4");
            System.out.println("To exit press 5");
            System.out.println("-----------------------------------\n");

            int choice = s.nextInt(); // local
            if (choice == 5) {
                System.out.println(costumer1.toString3());
                break;//exit the while loop
            }

            switch (choice) {
                // main switch...
                case 1:

                    System.out.println(costumer1.toString1());

                    break;

                case 2:

                    System.out.println(costumer1.toString2());

                    break;

                case 3:

                    while (true) {
                        System.out.println("\n-----------------------------------");
                        System.out.println("To subscribe with 1GB service press 1");
                        System.out.println("To subscribe with 2GB service press 2");
                        System.out.println("To subscribe with 5GB service press 3");
                        System.out.println("To subscribe with 10GB service press 4");
                        System.out.println("To subscribe with 5GB and 300MB wp service press 5");
                        System.out.println("To exit press 6");
                        System.out.println("-----------------------------------\n");

                        int choi = s.nextInt(); // local
                        if (choi == 6) {
                            break;
                        } else if (choi > 6) {
                            System.out.println("Wrong Input!");
                        }

                        switch (choi) {
                            //second switch...
                            case 1:
                                System.out.println("\n-----------------------------------");
                                System.out.println("Your remaining balance is: " + costumer1.get1GBsevice());
                                break;
                            case 2:
                                System.out.println("Your remaining balance is: " + costumer1.get2GBservice());
                                break;
                            case 3:
                                System.out.println("Your remaining balance is: " + costumer1.get5GBservice());
                                break;
                            case 4:
                                System.out.println("Your remaining balance is: " + costumer1.get10GBservice());
                                break;
                            case 5:
                                System.out.println("Your remaining balance is: " + costumer1.get5GBand300MBwpservice());
                                System.out.println("-----------------------------------\n");
                                break;

                        }
                    }
                default:
                    System.out.println("Tnvalid choice!");

                    break;

                case 4:
                    while (true) {
                        System.out.println("\n-----------------------------------");
                        System.out.println("To send feedback press 1");
                        System.out.println("To live chat with us press 2");
                        System.out.println("To report our service press 3");
                        System.out.println("To return to main menue press 4");
                        System.out.println("-----------------------------------\n");

                        int cho = s.nextInt(); // local
                        if (cho == 4) {
                            break;
                        }
                        switch (cho) {
                            //third switch...
                            case 1:
                                System.out.println("\n-----------------------------------");
                                System.out.println("Write your feedback: " + costumer1.feeed(s.nextLine()));
                                System.out.println("-----------------------------------\n");
                                break;
                            case 2:
                                System.out.println("\n-----------------------------------");
                                System.out.println("What's the problem: ");
                                String livechat = s.nextLine();
                                System.out.println("-----------------------------------\n");
                                break;
                            case 3:
                                System.out.println("\n-----------------------------------");
                                System.out.println("Write your report: ");
                                String report = s.nextLine();
                                System.out.println("-----------------------------------\n");

                                break;

                            default:
                                System.out.println("Invalid input!");
                        }
                    }
            }
        }

    }

}
